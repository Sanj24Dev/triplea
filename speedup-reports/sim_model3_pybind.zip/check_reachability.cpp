#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <queue>
#include <string>
#include <algorithm>
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include <iostream>
#include <chrono>

namespace py = pybind11;

struct Territory {
    std::string owner;
};

struct Unit {
    std::string owner;
    std::string type;
    
    bool operator==(const Unit& other) const {
        return owner == other.owner && type == other.type;
    }
};

// Hash function for Unit (needed for unordered_set)
namespace std {
    template <>
    struct hash<Unit> {
        size_t operator()(const Unit& u) const {
            return hash<string>()(u.owner) ^ (hash<string>()(u.type) << 1);
        }
    };
}

struct UnitInfo {
    std::string from_territory;
    Unit unit;
    int quantity;
};

struct AttackUnit {
    std::string unit_type;
    std::string from_territory;
    int quantity;
};

struct Move {
    std::string delegate;
    std::string to_terr;
    std::vector<AttackUnit> moves;
    bool end_phase;
    int strength;
    
    Move() : delegate("combat"), end_phase(false), strength(0) {}
};

using AdjacencyList = std::unordered_map<std::string, std::vector<std::string>>;
using TerritoryMap  = std::unordered_map<std::string, Territory>;

// Global adjacency list stored in C++
static AdjacencyList adjacency;

void set_adjacency(const AdjacencyList& adj) {
    adjacency = adj;
}

void clear_adjacency() {
    adjacency.clear();
}

bool can_reach(
    const std::string& from_territory,
    const std::string& to_territory,
    int move_range,
    const Unit& unit,
    const TerritoryMap& territories,
    const std::unordered_set<std::string>& my_territories
) {
    std::queue<std::pair<std::string, int>> queue;
    std::unordered_set<std::string> visited;

    queue.emplace(from_territory, 0);
    visited.insert(from_territory);

    while (!queue.empty()) {
        auto [current, steps] = queue.front();
        queue.pop();

        if (steps >= move_range)
            continue;

        auto it = adjacency.find(current);
        if (it == adjacency.end())
            continue;

        for (const std::string& neighbor : it->second) {
            if (visited.count(neighbor))
                continue;

            const std::string& terr_owner = territories.at(neighbor).owner;

            if (unit.type == "armour") {
                if (terr_owner == unit.owner || terr_owner == "Neutral") {
                    // allowed
                }
                else {
                    if (neighbor != to_territory)
                        continue;
                }
            }
            else {
                if (neighbor != to_territory &&
                    my_territories.count(neighbor) == 0) {
                    continue;
                }
            }

            visited.insert(neighbor);
            if (neighbor == to_territory)
                return true;

            queue.emplace(neighbor, steps + 1);
        }
    }

    return false;
}



PYBIND11_MODULE(check_reachability_cpp, m) {
    py::class_<Unit>(m, "Unit")
        .def(py::init<>())
        .def_readwrite("owner", &Unit::owner)
        .def_readwrite("type", &Unit::type);

    py::class_<Territory>(m, "Territory")
        .def(py::init<>())
        .def_readwrite("owner", &Territory::owner);

    py::class_<UnitInfo>(m, "UnitInfo")
        .def(py::init<>())
        .def_readwrite("from_territory", &UnitInfo::from_territory)
        .def_readwrite("unit", &UnitInfo::unit)
        .def_readwrite("quantity", &UnitInfo::quantity);

    py::class_<AttackUnit>(m, "AttackUnit")
        .def(py::init<>())
        .def_readwrite("unit_type", &AttackUnit::unit_type)
        .def_readwrite("from_territory", &AttackUnit::from_territory)
        .def_readwrite("quantity", &AttackUnit::quantity);

    py::class_<Move>(m, "Move")
        .def(py::init<>())
        .def_readwrite("delegate", &Move::delegate)
        .def_readwrite("to_terr", &Move::to_terr)
        .def_readwrite("moves", &Move::moves)
        .def_readwrite("end_phase", &Move::end_phase)
        .def_readwrite("strength", &Move::strength); 

    m.def("set_adjacency", &set_adjacency,
          "Set the global adjacency list (call once at game start)");
    
    m.def("clear_adjacency", &clear_adjacency,
          "Clear the global adjacency list (optional cleanup)");

    m.def("can_reach", &can_reach,
          "Fast BFS reachability check");
}